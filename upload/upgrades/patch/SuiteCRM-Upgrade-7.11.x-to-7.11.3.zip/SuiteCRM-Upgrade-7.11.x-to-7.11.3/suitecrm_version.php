<?php
if (!defined('sugarEntry') || !sugarEntry) {
    die('Not A Valid Entry Point');
}

$suitecrm_version      = '7.11.3';
$suitecrm_timestamp    = '2019-03-28 17:00:00';
