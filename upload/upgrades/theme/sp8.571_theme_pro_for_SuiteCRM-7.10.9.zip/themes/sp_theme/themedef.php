<?php

if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');


$themedef = array(
    'name'  => "Sugar Project theme",
    'description' => "Sugar Project theme",
    'version' => array(
        'regex_matches' => array('.*'),
        ),
    'group_tabs' => true,
    );

