
###### About Duplicate Checking ######

Duplicate Record Checking in SuiteCRM. Check the Duploicate Records in Account, Contact & Lead Module base on Name, Contact Number & Email Address.

## Configuration after addon successfully installed. ##

1.Active the addon
2.Goto Admin Panel of SuiteCRM then scroll the page below and click on Duplicate Checking Configuration
3.Copy the License Key from you have downloaded addon under your Purchases to the License Key box in SuiteCRM Store and then Click on Validate.


mailto - info@dreamertechs.com
