<?php

$action_view_map['dcconfig'] = 'dcconfig';
