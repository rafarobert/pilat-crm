<?php

$mod_strings['LBL_DT_DUPLICATE_CHECKING'] = 'Duplicate Checking Configuration Panel';

$mod_strings['LBL_DT_DUPLICATE_CHECKING_LICENSE_TITLE'] = 'License Configuration';
$mod_strings['LBL_DT_DUPLICATE_CHECKING_LICENSE'] = 'Manage and configure the license for this add-on';

$mod_strings['LBL_DT_DUPLICATE_CHECKING_CONFIGURATION'] = 'Duplicate Checking Configuration Settings';
$mod_strings['LBL_DT_DUPLICATE_CHECKING_MESSAGE'] = 'Duplicate Checking on Account, Contact And Lead Module';

