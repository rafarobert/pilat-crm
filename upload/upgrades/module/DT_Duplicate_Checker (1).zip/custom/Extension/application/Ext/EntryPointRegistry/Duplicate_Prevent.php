<?php

  $entry_point_registry['Prevent_Duplicate'] = array(
    'file' => 'modules/Duplicate_Preventive/PreventDuplicate.php',
    'auth' => true
  );