<?php
if (!defined('sugarEntry') || !sugarEntry)
    die('Not A Valid Entry Point');

function post_install() {

    global $app_list_strings, $current_language;
    global $dictionary, $current_user, $sugar_version;
    global $db;
    require_once ('modules/ModuleBuilder/MB/ModuleBuilder.php');
    require_once('modules/ModuleBuilder/parsers/parser.dropdown.php');
    require_once('modules/ModuleBuilder/parsers/ParserFactory.php');


    $_REQUEST['view_package'] = 'studio';
    $list_sms_field = '[["",""],["Accounts","Accounts"],["Contacts","Contacts"],["Leads","Leads"]]';
    $parserDropDown = new ParserDropDown();
    $parserDropDown->saveDropDown(array(
        'dropdown_lang' => $current_language,
        'dropdown_name' => 'sms_module_list',
        'view_package' => 'studio',
        'view_module' => '',
        'use_push' => 'true',
        'list_value' => $list_sms_field,
    ));

    //emailTemplates_type_list
    $list_sms_field_wf = '[["whatsapp","WhatsApp"]]';
    $parserDropDown1 = new ParserDropDown();
    $parserDropDown1->saveDropDown(array(
        'dropdown_lang' => $current_language,
        'dropdown_name' => 'emailTemplates_type_list',
        'view_package' => 'studio',
        'view_module' => '',
        'use_push' => 'true',
        'list_value' => $list_sms_field_wf,
    ));

    //call_status_dom 
    $list_sms_field_cs = '[["Sent","Sent"],["Received","Received"],["Failure","Failure"],["Pending","Pending"]]';
    $parserDropDown2 = new ParserDropDown();
    $parserDropDown2->saveDropDown(array(
        'dropdown_lang' => $current_language,
        'dropdown_name' => 'call_status_dom',
        'view_package' => 'studio',
        'view_module' => '',
        'use_push' => 'true',
        'list_value' => $list_sms_field_cs,
    ));

    //emailTemplates_type_list_no_workflow
    $list_sms_field_wff = '[["whatsapp","WhatsApp"]]';
    $parserDropDown3 = new ParserDropDown();
    $parserDropDown3->saveDropDown(array(
        'dropdown_lang' => $current_language,
        'dropdown_name' => 'emailTemplates_type_list_no_workflow',
        'view_package' => 'studio',
        'view_module' => '',
        'use_push' => 'true',
        'list_value' => $list_sms_field_wff,
    ));



    require_once("modules/Administration/QuickRepairAndRebuild.php");
    $randc = new RepairAndClear();
    $randc->repairAndClearAll(array('clearAll'), array(translate('LBL_ALL_MODULES')), 'false', 'false');
    ?>


    <br>
    <div style="margin: 22px;">
        <span style="font-size: 1.5em;color: green"><strong>WhatsApp Integration addon installed successfully.</strong></span>
        <ul>
            <li style="">WhatsApp Configuration Documentation <a href="https://store.suitecrm.com/docs/whatsapp-integration-with-suitecrm"> Click Here </a> </li>
            <li style="">For Lisence Activation <a href="index.php?module=DT_Whatsapp&action=license"> Click Here </a> </li>
        </ul>
        <span style="font-size: 1.5em;color: blue"><strong>Contact us !!</strong></span>
        <br>
        mailto - info@dreamertechs.com
    </div>


    <?php
}
?>
