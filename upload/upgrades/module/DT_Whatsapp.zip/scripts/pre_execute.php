<?php


$GLOBALS['log']->fatal("DT_Whatsapp Started - Renaming existing files.");
if (file_exists("custom/include/SugarFields/Fields/Phone/DetailView.tpl"))
{
    $GLOBALS['log']->fatal("DT_Whatsapp -> custom/include/SugarFields/Fields/Phone/DetailView.tpl");
    rename("custom/include/SugarFields/Fields/Phone/DetailView.tpl", "custom/include/SugarFields/Fields/Phone/DetailView.tpl_dtwhatsapp");
}

if (file_exists("custom/include/SugarFields/Fields/Phone/ListView.tpl"))
{
    $GLOBALS['log']->fatal("DT_Whatsapp -> custom/include/SugarFields/Fields/Phone/ListView.tpl");
    rename("custom/include/SugarFields/Fields/Phone/ListView.tpl", "custom/include/SugarFields/Fields/Phone/ListView.tpl_dtwhatsapp");
}

if (file_exists("custom/modules/AOW_Actions/actions/actionSendEmail.php"))
{
    $GLOBALS['log']->fatal("DT_Whatsapp -> custom/modules/AOW_Actions/actions/actionSendEmail.php");
    rename("custom/modules/AOW_Actions/actions/actionSendEmail.php", "custom/modules/AOW_Actions/actions/actionSendEmail.php_dtwhatsapp");
}

if (file_exists("custom/modules/EmailTemplates/DetailView.html"))
{
    $GLOBALS['log']->fatal("DT_Whatsapp -> custom/modules/EmailTemplates/DetailView.html");
    rename("custom/modules/EmailTemplates/DetailView.html", "custom/modules/EmailTemplates/DetailView.html_dtwhatsapp");
}

if (file_exists("custom/modules/EmailTemplates/DetailView.php"))
{
    $GLOBALS['log']->fatal("DT_Whatsapp -> custom/modules/EmailTemplates/DetailView.php");
    rename("custom/modules/EmailTemplates/DetailView.php", "custom/modules/EmailTemplates/DetailView.php_dtwhatsapp");
}

if (file_exists("custom/modules/EmailTemplates/EditView.html"))
{
    $GLOBALS['log']->fatal("DT_Whatsapp -> custom/modules/EmailTemplates/EditView.html");
    rename("custom/modules/EmailTemplates/EditView.html", "custom/modules/EmailTemplates/EditView.html_dtwhatsapp");
}

if (file_exists("custom/modules/EmailTemplates/EditView.php"))
{
    $GLOBALS['log']->fatal("DT_Whatsapp -> custom/modules/EmailTemplates/EditView.php");
    rename("custom/modules/EmailTemplates/EditView.php", "custom/modules/EmailTemplates/EditView.php_dtwhatsapp");
}

if (file_exists("custom/modules/EmailTemplates/EditViewMain.html"))
{
    $GLOBALS['log']->fatal("DT_Whatsapp -> custom/modules/EmailTemplates/EditViewMain.html");
    rename("custom/modules/EmailTemplates/EditViewMain.html", "custom/modules/EmailTemplates/EditViewMain.html_dtwhatsapp");
}


$GLOBALS['log']->fatal("DT_Whatsapp Ended - Renaming existing files.");
?>