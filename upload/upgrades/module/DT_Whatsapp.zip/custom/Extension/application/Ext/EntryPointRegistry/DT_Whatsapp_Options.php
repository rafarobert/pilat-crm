<?php

  $entry_point_registry['DT_Whatsapp_Options'] = array(
    'file' => 'modules/DT_Whatsapp/DT_Whatsapp_Options.php',
    'auth' => true
  );

  $entry_point_registry['DT_Whatsapp_Inbound'] = array(
    'file' => 'modules/DT_Whatsapp/DT_Whatsapp_Inbound.php',
    'auth' => false
  );