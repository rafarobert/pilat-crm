<?php

$mod_strings['LBL_WHATSAPP_STATUS'] = 'Whatsapp read status';