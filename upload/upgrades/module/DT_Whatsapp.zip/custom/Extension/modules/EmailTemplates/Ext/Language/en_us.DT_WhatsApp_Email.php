<?php

$mod_strings['LBL_SMS_MODULE_C'] = 'WhatsApp Module';

