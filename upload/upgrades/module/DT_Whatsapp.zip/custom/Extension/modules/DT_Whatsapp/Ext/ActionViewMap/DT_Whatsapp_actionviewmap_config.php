<?php

$action_view_map['whatsapp_config'] = 'whatsapp_config';
