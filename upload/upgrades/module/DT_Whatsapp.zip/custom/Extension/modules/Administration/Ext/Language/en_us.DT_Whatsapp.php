<?php

$mod_strings['LBL_DTWHATSAPP'] = 'Waboxapp WhatsApp License Add-on';
$mod_strings['LBL_DTWHATSAPP_LICENSE_TITLE'] = 'License Configuration';
$mod_strings['LBL_DTWHATSAPP_LICENSE'] = 'Manage and configure the license for this add-on';

$mod_strings['LBL_DTWHATSAPP_LICENSE_WHATSAPP_CONFIGURATION'] = 'Whatsapp API Settings';
$mod_strings['LBL_DTWHATSAPP_LICENSE_MESSAGE'] = 'Configure Waboxapp API credentials details';

