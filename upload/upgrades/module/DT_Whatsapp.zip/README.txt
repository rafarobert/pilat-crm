
###### About DT Whatsapp Integration ######

WhatsApp Integration with SuiteCRM. With WhatsApp, you'll get fast, simple, secure messaging available on phones all over the world and all conversation will be logged in SuiteCRM.

## Configuration after addon successfully installed. ##

1.Active the addon
2.Goto Admin Panel of SuiteCRM then scroll the page below and click on License Configuration
3.Copy the License Key from you have downloaded addon under your Purchases to the License Key box in SuiteCRM Store and then Click on Validate.

## Configure Credentials ##

After Successfully configured this setting all incoming and outgoing Whatsapp log will be captured in your configured SuiteCRM.

## Contact us ##

mailto - info@dreamertechs.com
