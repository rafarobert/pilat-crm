<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');

$license_strings = array (
    'LBL_STEPS_TO_LOCATE_KEY_TITLE' => 'Para localizar la clave',
    'LBL_STEPS_TO_LOCATE_KEY' => '1. Ingresa para <a href="https://www.sugaroutfitters.com" target="_blank">SugarOutfitters</a><br/>2. Ir a Account->Purchases</br>3. Busque la clave para la compra de este complemento<br/>4. Pegar en el cuadro Clave de licencia por debajo de<br/>5. Hacer clic en "Validate"',
    'LBL_LICENSE_KEY' => 'clave de licencia',
    'LBL_CURRENT_USERS' => 'Conde Usuario actual',
    'LBL_LICENSED_USERS' => 'N�mero de usuarios con licencia',
    'LBL_VALIDATE_LABEL' => 'Validar',
    'LBL_VALIDATED_LABEL' => 'Validado',
);

