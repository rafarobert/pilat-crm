<?php

$mod_strings['LBL_ANALYTICREPORTING'] = 'Analytic Reporting';
$mod_strings['LBL_ANALYTICREPORTING_LICENSE_TITLE'] = 'License Configuration';
$mod_strings['LBL_ANALYTICREPORTING_LICENSE'] = 'Manage and configure the license for Analytic Reporting';
