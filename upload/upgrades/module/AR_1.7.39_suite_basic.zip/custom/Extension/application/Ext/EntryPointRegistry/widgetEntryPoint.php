<?php
    $entry_point_registry['analyticReportWidget'] = array(
        'file' => 'widget.php',
        'auth' => true
    );
?>