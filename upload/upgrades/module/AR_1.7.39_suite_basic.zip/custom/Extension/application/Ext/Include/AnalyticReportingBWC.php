<?php
// Set BCW mode for AnalyticReporting module
$bwcModules[] = 'AnalyticReporting';