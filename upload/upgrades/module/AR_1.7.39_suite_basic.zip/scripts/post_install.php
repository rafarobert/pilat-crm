<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');

require_once 'include/dir_inc.php';

function post_install() {
    global $sugar_config, $sugar_version;

    // Module package list
    $module_list = array(
        'AnalyticReporting'
    );

    // DEPRECATED
    // Add to AJAX banned modules only in CE
    if($GLOBALS['sugar_flavor'] == 'CE') {
        // Disable AjaxUI for module
        require_once 'modules/Configurator/Configurator.php';
        $cfg = new Configurator();
        $overrideArray = $cfg->readOverride();
        if(array_key_exists('addAjaxBannedModules',$overrideArray)) {
            $disabled_modules = $overrideArray['addAjaxBannedModules'];
            $updatedArray = array_merge($disabled_modules, array_diff($module_list, $disabled_modules));
        } else { 
            $updatedArray = $module_list;
        }

        $cfg->config['addAjaxBannedModules'] = empty($updatedArray) ? FALSE : $updatedArray;
        $cfg->handleOverride();
    }

    //install table for user management
    global $db;
    if (!$db->tableExists('so_users')) {

        $fieldDefs = array(
            'id' => array (
              'name' => 'id',
              'vname' => 'LBL_ID',
              'type' => 'id',
              'required' => true,
              'reportable' => true,
            ),
            'deleted' => array (
                'name' => 'deleted',
                'vname' => 'LBL_DELETED',
                'type' => 'bool',
                'default' => '0',
                'reportable' => false,
                'comment' => 'Record deletion indicator',
            ),
            'shortname' => array (
                'name' => 'shortname',
                'vname' => 'LBL_SHORTNAME',
                'type' => 'varchar',
                'len' => 255,
            ),
            'user_id' => array (
                'name' => 'user_id',
                'rname' => 'user_name',
                'module' => 'Users',
                'id_name' => 'user_id',
                'vname' => 'LBL_USER_ID',
                'type' => 'relate',
                'isnull' => 'false',
                'dbType' => 'id',
                'reportable' => true,
                'massupdate' => false,
            ),
        );
        
        $indices = array(
            'id' => array (
                'name' => 'so_userspk',
                'type' => 'primary',
                'fields' => array (
                    0 => 'id',
                ),
            ),
            'shortname' => array (
                'name' => 'shortname',
                'type' => 'index',
                'fields' => array (
                    0 => 'shortname',
                ),
            ),
        );
        $db->createTableParams('so_users',$fieldDefs,$indices);
    }

    // Quick Repair & Rebuild
    $module = array('All Modules');
    $selected_actions = array('clearAll');
    require_once 'modules/Administration/QuickRepairAndRebuild.php';
    $randc = new RepairAndClear();
    $randc->repairAndClearAll($selected_actions, $module, false, false);


}