<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');

require_once 'include/dir_inc.php';
require_once dirname(dirname(__FILE__)) . '/modules/AnalyticReporting/profiles/FunctionWrapper.php';

function pre_install() {
	global $sugar_config, $sugar_version;
	$adb = DBManagerFactory::getInstance();

	//check if table already exists
	$moduleTableExists = checkTableExists($adb, 'advancedreports');
	
	// Create tables
	createTables($adb);
	
	if(!$moduleTableExists){
		importSQLFromFile($adb);
	}else{
		echo "Previous installation detected, SQL data importing skipped, \n<br />";
	}

    // Try to check if config table exists
    if(!checkTableExists($adb, 'advancedreports_config')) {
        createConfigTable($adb);
    }
    initConfig($adb);
    echo "AnalyticReporting installation script done.\n<br />";
	cleanup();
	echo "Temporary files removed successfully.\n<br />";
}

/**
 * Set initial config after config table has been created
 */
function initConfig($adb) {
    echo "Set initial config...\n<br />";
    $config = array(
        'version' => 'sugarcrmlite',
        'limit' => '20',
        'dateformat' => 'd-m-Y',
        'builderPublicAccess' => 'false',
        'showNullValues' => 'false',
        'apiEndpoint' => 'http://api.dev.itsapiens.eu/',
		'key' => ''
    );

    // Try to add key file in config if exists
    $keyFile = dirname(dirname(__FILE__)) . '/modules/AnalyticReporting/key.php';
    if(FunctionWrapper::_is_file($keyFile)) {
        echo "Key found, adding...\n<br />";
        $key = implode("\n", FunctionWrapper::_file($keyFile));
        // Add key contents to keyValue array
        $config["key"] = $key;
    }

    // Insert config values
    foreach ($config as $key => $value) {
        $found = $adb->getOne("SELECT COUNT(*) AS count FROM `advancedreports_config` WHERE `key` = '".$key."' LIMIT 1");
        if($found < 1) {
            $adb->query("INSERT INTO `advancedreports_config` (`key`, `value`) VALUES ('".$key."', '".$value."')");
        }
    }
    echo "Done.\n<br />";
}

/**
 * Import base data into AnalyticReporting table from import.sql
 */
function importSQLFromFile($adb, $filePath = false) {
	// CE have different SQL import file than other
	$fileName = 'importpro.txt';
	if($GLOBALS['sugar_flavor'] == 'CE') {
		$fileName = 'importce.txt';
	}else if($GLOBALS['sugar_flavor'] == 'ENT'){
		$fileName = 'importent.txt';
	}

	if(!$filePath) {
		// Import SQL into tables (cache/upgrades/temp/<HASH>/import.sql)
		$filePath = dirname(__FILE__) . '/' . $fileName; // @ONDEMANDFIX
	}

	// Temporary variable, used to store current query
	$templine = '';
	$successCount = 0;
	$errorCount = 0;

	// Read in entire file
	$lines = FunctionWrapper::_file($filePath);
	
	//[#5932 Start]
	$installedModuleList = array_merge($GLOBALS['moduleList'],$GLOBALS['beanList']);
	
	$checkIfModuleExists = true;
	$reportsCounter = 0;
	//[#5932 End] 
	foreach ($lines as $line) {
		// Skip it if it's a comment
		if (substr($line, 0, 2) == '--' || $line == '') {
			continue;
		}
		//[#5932 Start]
		$reportsCounter++;
		if($checkIfModuleExists){
			if(substr($line, 0, 6) == 'INSERT'){
				$reportsCounter--;
				//Stop cheking if module exists on category import
				if (strpos($line, 'advancedreports_categories') !== false) {
				    $checkIfModuleExists = false;
				}
			}else{
				$dividedLine = explode(',', $line, 6);
				$reportModules = array();
				$mainModulename = trim(str_replace("'", "", $dividedLine[3]));
				//empty in combined reports
				if(!empty($mainModulename))$reportModules[] = $mainModulename;
				
				//decode from hexadecimal
				$modules = json_decode(pack("H*" , substr($dividedLine[4],3)));
				for($i=0,$l=count($modules);$i<$l;$i++){
					$reportModules[] = trim($modules[$i][0]);
				}

				
				foreach($reportModules as $module){
					if(!in_array($module, $installedModuleList)){
						$reportsCounter--;
						if(substr(trim($line), -1, 1) == ';'){
							$line = ";";
						}else{
							$line = "";
						}
						break;
					}
				}
			}
		}
		//[#5932 End] 
		// Add this line to the current segment
		$templine .= $line;
		// If it has a semicolon at the end, it's the end of the query
		if (substr(trim($line), -1, 1) == ';') {
			//import only if there is something to import
			if($reportsCounter>0){
				//remove extra comma
				if (substr(trim($templine), -3, 1) == ','){
					$templine = substr($templine, 0, -3);
					$templine.=";";
				}elseif(substr(trim($templine), -2, 1) == ','){
					$templine = substr($templine, 0, -2);
					$templine.=";";
				}
				// Perform the query
				$result = $adb->query($templine);
				if($result) {
					// Query performed sucessfully
					$successCount++;
				} else {
					// Error while performing query
					$errorCount++;
					echo "Error performing query <b>$templine : ". mysql_error() . "</b>\n<br />";
				}
			}
			// Reset temp variable to empty
			$templine = '';
			$reportsCounter=0;
		}
	}

	echo "SQL data imported successfully ($successCount suceess, $errorCount errors)\n<br />";
}

/**
 * Create config table
 */
function createConfigTable($adb) {
    $adb->query("CREATE TABLE IF NOT EXISTS `advancedreports_config` (
        `key` varchar(32) DEFAULT NULL,
        `value` text,
        UNIQUE KEY `key` (`key`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8");
}

/**
 * Create tables for 
 */
function createTables($adb) {

	$adb->query("SET foreign_key_checks = 0;");

	//$adb->query("DROP TABLE IF EXISTS `advancedreports`;");
	$adb->query("CREATE TABLE IF NOT EXISTS `advancedreports` (
		`id` int(11) NOT NULL AUTO_INCREMENT,
		`category_id` int(19) NOT NULL,
		`sequence` int(10) NOT NULL,
		`module` varchar(255) NOT NULL,
		`related_data` blob NOT NULL,
		`fields` blob NOT NULL,
		`filters` blob NOT NULL,
		`grouping` blob NOT NULL,
		`aggregates` longblob NOT NULL,
		`totalAggregates` blob NOT NULL,
		`title` varchar(255) NOT NULL,
		`description` text,
		`options` blob NOT NULL,
		`labels` longblob NOT NULL,
		`chart` blob NOT NULL,
		`owner` varchar(36) NOT NULL,
		`shared` int(11) NOT NULL,
		`sharedlevel` int(11) NOT NULL DEFAULT '0',
		`iscombined` int(11) NOT NULL DEFAULT '0',
		`combinedfields` blob,
		`visible` int(1) NOT NULL DEFAULT '1',
		`calcFields` blob,
		`assigned_user_id` varchar(36) DEFAULT NULL,
		`modified_user_id` varchar(36) DEFAULT NULL,
		`deleted` int(36) DEFAULT '0',
		PRIMARY KEY (`id`)
	) ENGINE=InnoDB  DEFAULT CHARSET=utf8;");
	
	$adb->query("ALTER TABLE `advancedreports` ADD `columnstate` BLOB NULL DEFAULT NULL;"); // #5098
	
	//$adb->query("DROP TABLE IF EXISTS `advancedreports_categories`;");
	$adb->query("CREATE TABLE IF NOT EXISTS `advancedreports_categories` (
		`id` int(19) NOT NULL AUTO_INCREMENT,
		`parent_id` int(19) DEFAULT NULL,
		`sequence` int(10) NOT NULL,
		`title` varchar(255) DEFAULT NULL,
		`description` varchar(255) DEFAULT NULL,
		`visible` int(1) NOT NULL DEFAULT '1',
		PRIMARY KEY (`id`)
	) ENGINE=MyISAM  DEFAULT CHARSET=utf8;");

	//$adb->query("DROP TABLE IF EXISTS `advancedreports_schedule`;");
	$adb->query("CREATE TABLE IF NOT EXISTS `advancedreports_schedule` (
		`id` int(11) NOT NULL,
		`interval` int(11) NOT NULL,
		`interval_options` varchar(5) NOT NULL,
		`time` varchar(5) NOT NULL,
		`nexttime` datetime NOT NULL,
		`formats` blob NOT NULL,
		UNIQUE KEY `uniqui` (`id`)
	) ENGINE=InnoDB DEFAULT CHARSET=utf8;");
	
	$adb->query("ALTER TABLE `advancedreports_schedule` ADD `emails` BLOB NULL DEFAULT NULL"); // #5872

	//$adb->query("DROP TABLE IF EXISTS `advancedreports_schedule_g`;");
	$adb->query("CREATE TABLE IF NOT EXISTS `advancedreports_schedule_g` (
		`id` int(11) NOT NULL,
		`group` varchar(36) NOT NULL,
		UNIQUE KEY `report_idx` (`id`,`group`),
		KEY `group` (`group`)
	) ENGINE=InnoDB DEFAULT CHARSET=utf8;");

	//$adb->query("DROP TABLE IF EXISTS `advancedreports_schedule_r`;");
	$adb->query("CREATE TABLE IF NOT EXISTS `advancedreports_schedule_r` (
		`id` int(11) NOT NULL,
		`role` varchar(36) NOT NULL,
		UNIQUE KEY `report_idx` (`id`,`role`),
		KEY `role` (`role`)
	) ENGINE=InnoDB DEFAULT CHARSET=utf8;");

	//$adb->query("DROP TABLE IF EXISTS `advancedreports_schedule_u`;");
	$adb->query("CREATE TABLE IF NOT EXISTS `advancedreports_schedule_u` (
		`id` int(11) NOT NULL,
		`user` varchar(36) NOT NULL,
		UNIQUE KEY `report_idx` (`id`,`user`),
		KEY `user` (`user`)
	) ENGINE=InnoDB DEFAULT CHARSET=utf8;");

	//$adb->query("DROP TABLE IF EXISTS `advancedreports_sharedgroups`;");
	$adb->query("CREATE TABLE IF NOT EXISTS `advancedreports_sharedgroups` (
		`report_id` int(11) NOT NULL,
		`group_id` varchar(36) NOT NULL,
		`level` int(11) NOT NULL,
		UNIQUE KEY `idx` (`report_id`,`group_id`),
		KEY `report_id` (`report_id`),
		KEY `user_id` (`group_id`)
	) ENGINE=InnoDB DEFAULT CHARSET=utf8;");

	//$adb->query("DROP TABLE IF EXISTS `advancedreports_sharedusers`;");
	$adb->query("CREATE TABLE IF NOT EXISTS `advancedreports_sharedusers` (
		`report_id` int(11) NOT NULL,
		`user_id` varchar(36) NOT NULL,
		`level` int(11) NOT NULL,
		UNIQUE KEY `idx` (`report_id`,`user_id`),
		KEY `report_id` (`report_id`),
		KEY `user_id` (`user_id`)
	) ENGINE=InnoDB DEFAULT CHARSET=utf8;");

	$adb->query("SET foreign_key_checks = 1;");

	// Optional constraints
	$adb->query("ALTER TABLE `advancedreports_schedule` ADD CONSTRAINT `advancedreports_schedule_ibfk_1` FOREIGN KEY (`id`) REFERENCES `advancedreports` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;");
	$adb->query("ALTER TABLE `advancedreports_schedule_g` ADD CONSTRAINT `advancedreports_schedule_g_ibfk_1` FOREIGN KEY (`id`) REFERENCES `advancedreports` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;");
	$adb->query("ALTER TABLE `advancedreports_schedule_r` ADD CONSTRAINT `advancedreports_schedule_r_ibfk_1` FOREIGN KEY (`id`) REFERENCES `advancedreports` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;");
	$adb->query("ALTER TABLE `advancedreports_schedule_u` ADD CONSTRAINT `advancedreports_schedule_u_ibfk_1` FOREIGN KEY (`id`) REFERENCES `advancedreports` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;");
}

function checkTableExists($adb, $tableName){
	$table = $adb->query("SHOW TABLES LIKE '".$tableName."';");
	if($table->num_rows > 0) {
		// Check for record existence too, maybe there is empty table
		$table = $adb->query('SELECT COUNT(*) FROM `'.$tableName.'`;');
		if($table->num_rows > 0) {
			return TRUE;
		}

		return false;
	}

	return FALSE;
}

//Perform cleanup operations
function cleanup(){
	$keyFile = dirname(dirname(__FILE__)) . '/modules/AnalyticReporting/key.php';
	if(file_exists($keyFile)) {
		if(suhosin_function_exists("chmod")){
			@FunctionWrapper::_chmod($keyFile, 0777);
		}
		// Try to delete key file
		if(suhosin_function_exists("unlink")){
			@FunctionWrapper::_unlink($keyFile);
		}

	}
}

function suhosin_function_exists($func) {
	if (extension_loaded('suhosin')) {
		$suhosin = @ini_get("suhosin.executor.func.blacklist");
		if (empty($suhosin) == false) {
			$suhosin = explode(',', $suhosin);
			$suhosin = array_map('trim', $suhosin);
			$suhosin = array_map('strtolower', $suhosin);
			return (function_exists($func) == true && array_search($func, $suhosin) === false);
		}
	}
	return function_exists($func);
}