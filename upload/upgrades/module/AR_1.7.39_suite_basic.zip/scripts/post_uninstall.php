<?php
// NOTE post_uninstall needs to be not function and it MUST be included into manifest file
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');

require_once 'include/dir_inc.php';

post_uninstall();

function post_uninstall() {
	global $sugar_config, $sugar_version;
	$adb = DBManagerFactory::getInstance();

	// Drop tables tables
	dropTables($adb);
}

/**
 * Drop tables after uninstall
 */
function dropTables($adb) {

	//$adb->query("DROP TABLE IF EXISTS `advancedreports_schedule`;");
	//$adb->query("DROP TABLE IF EXISTS `advancedreports_schedule_g`;");
	//$adb->query("DROP TABLE IF EXISTS `advancedreports_schedule_r`;");
	//$adb->query("DROP TABLE IF EXISTS `advancedreports_schedule_u`;");
	//$adb->query("DROP TABLE IF EXISTS `advancedreports_sharedgroups`;");
	//$adb->query("DROP TABLE IF EXISTS `advancedreports_sharedusers`;");
	//$adb->query("DROP TABLE IF EXISTS `advancedreports_categories`;");
	//$adb->query("DROP TABLE IF EXISTS `advancedreports`;");

	//echo "Tables dropped successfully\n<br />";
}