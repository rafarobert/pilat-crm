# INSTALLATION INSTRUCTIONS FOR ANALYTIC REPORTING FOR SUGARCRM

## Requirements

* SugarCRM CE/PRO/ENT or SuiteCRM starting from version 6.5
* At least 50Mb should be allowed in WEB server to upload module (php.ini values "upload_max_filesize" and "post_max_size" should be at least 50Mb)
* Check write permissions to module directory (/modules), because after installation will be promted to download additional fonts for PDF export.


## Browser compatibility

* Firefox 30 +
* Google Chrome 30 +
* Internet Explorer 11 +


## Installation

1. Create backup of all your SugarCRM/SuiteCRM system (files and database). It's better to make full backup of your SugarCRM/SuiteCRM system before any changes are made.

2. Log in to your SugarCRM/SuiteCRM system as Administrator and go to Admin->Module Loader and browse for module ZIP file.

3. Select your archived copy of Analytic Reporting module and click on button "Upload".

4. If module successfully uploaded, press on "Install" button.

5. License agreement step will appear. Click on "I accept the license agreement" and continue.

6. If all went good - you can use your new Analytic Reporting tool in SugarCRM/SuiteCRM :)

7. If you face any issues, please contact us: info@itsapiens.eu


## Third party libraries

In Analytic Reporting tool for SugarCRM/SuiteCRM installation is included third party libraries such as:

* jQuery
* jQuery UI
* jQuery Select2
* jQuery Multiselect
* jQuery event drag
* jquery DoubleScroll
* saveSvgAsPng
* Ractive.js
* underscore.js
* D3.js
* D3-context-menu
* D3-funnel
* D3-gauge
* NVD3.js
* SlickGrid
* Pace.js
* jsTree
* jsTree-Grid
* PHPExcel
* canvg
* Leaflet
* Leaflet-dvf
* Leaflet-providers
* Leaflet-image
* moment.js


## Translations

Analytic Reporting is delivered in English (en_us) language, to translate Analytic Reporting for your language, you should make modifications in your language files.

In your /modules/AnalyticReporting/languages/YOUR_LANGUAGE.lang.php array can be added following translations for Analytic Reporting (You can see example in SUGARCRM_ROOT/modules/AnalyticReporting/language/en_us.lang.php).


## Support

For support, please, contact us: info@itsapiens.eu