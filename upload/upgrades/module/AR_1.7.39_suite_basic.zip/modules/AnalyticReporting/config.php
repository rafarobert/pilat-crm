<?php
/**
 *
 * AnalyticReporting config file
 *
 */

return array(
	// Current module version (do not change, it will not add more functionality!)
	'version' => 'sugarcrmlite',

	// Limitation of records per page
	'limit' => 20,

);