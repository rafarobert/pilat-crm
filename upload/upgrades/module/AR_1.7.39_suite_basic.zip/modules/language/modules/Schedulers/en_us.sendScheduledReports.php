<?php

$mod_strings = array_merge($mod_strings,
	array(
		 'LBL_SENDSCHEDULEDREPORTS' => "Analytic Reporting Send Scheduled Reports",
	)
);