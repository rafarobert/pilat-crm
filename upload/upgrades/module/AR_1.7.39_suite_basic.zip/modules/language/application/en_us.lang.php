<?php

$app_list_strings['moduleList']['AnalyticReporting'] = 'Analytic Reporting';