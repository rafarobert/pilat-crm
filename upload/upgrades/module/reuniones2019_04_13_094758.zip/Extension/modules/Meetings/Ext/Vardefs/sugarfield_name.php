<?php
 // created: 2019-04-13 09:29:41
$dictionary['Meeting']['fields']['name']['required']=false;
$dictionary['Meeting']['fields']['name']['inline_edit']=true;
$dictionary['Meeting']['fields']['name']['comments']='Meeting name';
$dictionary['Meeting']['fields']['name']['merge_filter']='disabled';
$dictionary['Meeting']['fields']['name']['full_text_search']=array (
);

 ?>