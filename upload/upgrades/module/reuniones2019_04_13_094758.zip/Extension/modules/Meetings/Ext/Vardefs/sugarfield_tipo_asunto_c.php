<?php
 // created: 2019-04-13 09:40:07
$dictionary['Meeting']['fields']['tipo_asunto_c']['inline_edit']='1';
$dictionary['Meeting']['fields']['tipo_asunto_c']['labelValue']='tipo asunto';

 ?>