<?php
 // created: 2019-02-08 17:02:05
$dictionary['Meeting']['fields']['jjwg_maps_address_c']['inline_edit']=1;

 ?>