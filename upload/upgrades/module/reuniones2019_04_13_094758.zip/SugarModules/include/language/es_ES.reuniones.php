<?php 
$app_list_strings['parent_type_display'] = array (
  'Accounts' => 'Cliente',
  'Leads' => 'Prospecto',
);$app_list_strings['asunto_reunion_list'] = array (
  'VISITA_PROYECTO' => 'Visita al Proyecto',
  'ACTA_DE_ENTREGA' => 'Visita al proyecto (Acta de entrega)',
  'FIRMA_MINUTA' => 'Firma Minuta',
  'FIRMA_PROTOCOLO' => 'Firma de protocolo en la Notaria',
  'ENTREGA_TESTIMONIO' => 'Entrega del testimonio',
);