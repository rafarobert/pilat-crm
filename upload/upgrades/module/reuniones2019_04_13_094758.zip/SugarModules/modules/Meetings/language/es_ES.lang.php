<?php 
 // created: 2019-04-13 09:47:57
$mod_strings['LBL_ACCOUNT'] = 'Cliente';
$mod_strings['LBL_LEADS'] = 'Prospectos';
$mod_strings['LBL_LEADS_SUBPANEL_TITLE'] = 'Prospectos';
$mod_strings['LBL_TIPO_ASUNTO'] = 'Asunto';
$mod_strings['LBL_SUBJECT'] = 'Asunto:';

?>
