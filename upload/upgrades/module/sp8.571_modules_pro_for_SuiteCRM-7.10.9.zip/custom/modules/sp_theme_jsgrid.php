<?php
$entry_point_registry['jsgrid'] = array('file' => 'custom/modules/jsgrid_epr.php', 'auth' => true);
?>